from django.apps import AppConfig


class ServicesEventsConfig(AppConfig):
    name = 'Services_events'
