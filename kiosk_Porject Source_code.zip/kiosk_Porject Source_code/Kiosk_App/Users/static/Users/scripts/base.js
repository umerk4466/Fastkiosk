// show animation until page is not loaded
$(window).on('load', function() {
    $(".loader").fadeOut();
});